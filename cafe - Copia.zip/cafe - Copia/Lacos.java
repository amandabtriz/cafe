

package com.mycompany.maveproject1;
import javax.swing.JOptionPane;

public class Lacos {
   public static void main(String[] args) {
       Cafe cafe = new Cafe();
       int num = Integer.parseInt(JOptionPane.showInputDialog( "Escolha o café:" +
               "\n 1 - Café com leite" +
               "\n 2 - Capuccino" +
               "\n 3 - Café Latte" +
               "\n 4 - Café Java" +
               "\n 5 - Café com chocolate" +
               "\n 6 - Café forte"
           )
       );
       JOptionPane.showMessageDialog(
           null,"O valor é R$:" + cafe.tipocafes(num) );
       int resp = Integer.parseInt(JOptionPane.showInputDialog(null,"confirme no botao 1-sim 2-não"));
       if(cafe.preparar(resp) == 1){
       JOptionPane.showMessageDialog(null,"Preparando?");
       } else {
           JOptionPane.showMessageDialog(null, "Cancelado");
       }

   }
}