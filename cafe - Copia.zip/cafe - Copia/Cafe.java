package com.mycompany.maveproject1;
 
/**

*

* @author labs

*/

public class Cafe {

    public double tipocafes(int num){

        if (num == 1){

            return 10.40;

        } else if(num == 2){

            return 12.60;

        } else if(num == 3){

            return 13.30;

        } else if(num == 4){

            return 14.50;

        } else if(num == 5){

            return 15650;

        } else if(num == 6){

            return 10.60;

        }

        return 0;

    }

    public int preparar(int num){

        if(num == 1){

            return 1;

        } else {

            return 2;

        }

    }

}
 